function w = trainbagcont(X,Y,nrnds,basetrain,w,varargin)

basetest = w{1};
j = length(w);
for i=1:nrnds,
	modeli = basetrain(X,Y,getbootstrap(size(Y,1)),varargin{:});
	w{j+i*2-1} = modeli;
	w{j+i*2} = 1.0/nrnds;
end;

nrnds = (length(w)-1)/2;

for i=3:2:length(w)
	w{i} = 1.0/nrnds;
end;

function alpha = getbootstrap(n)

alpha = hist(rand(n,1),((1:n)-0.5)/n)';
