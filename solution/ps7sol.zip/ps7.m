load -ascii class2d.ascii

cX = class2d(:,1:2);
cY = class2d(:,3);

treedepth = 3;
minleaf = 5;

ntree = [10 20 50 100];
sp = 1;
lastB = 0;
for B = ntree
	if (lastB==0)
		w = trainbag(cX,cY,B,@traindtw,@dt,treedepth,@splitentropy,minleaf);
	else 
		w = trainbagcont(cX,cY,B-lastB,@traindtw,w,treedepth,@splitentropy,minleaf);
	end;
	lastB = B;
	figure(1);
	subplot(2,2,sp);
	plotall(cX,cY,@ensemble,50,w);
	title(sprintf('Bagging with %d trees',B));
	sp = sp+1;
end;

ls = [0 2 5 10];
sp = 1;
for l = ls
	w2 = retrainensemble(cX,cY,l,w);
	figure(2);
	subplot(2,2,sp);
	plotall(cX,cY,@ensemble,50,w2);
	title(sprintf('retrain lambda=%g, ntrees=%d',l,(length(w2)-3)/2));
	sp = sp+1;
end;

sp = 1;
lastB = 0;
for B = ntree
	if (lastB==0)
		[w,al] = trainboost(cX,cY,B,@traindtw,@dt,treedepth,@splitentropy,minleaf);
	else 
		[w,al] = trainboostcont(cX,cY,B-lastB,@traindtw,w,al,treedepth,@splitentropy,minleaf);
	end;
	lastB = B;
	figure(3);
	subplot(2,2,sp);
	plotall(cX,cY,@ensemble,50,w);
	title(sprintf('Boosting with %d trees',B));
	sp = sp+1;
end;


load -ascii spamtrain.ascii;
load -ascii spamtest.ascii;

bXtrain = spamtrain(:,1:57);
bYtrain = spamtrain(:,58);
bXtest = spamtest(:,1:57);
bYtest = spamtest(:,58);

%---------------------------------

treedepth = 6;
minleaf = 100;

figure(4);
hold off;
plotx = [];
ploty = [];
lastB = 0;
for B = 20:20:200
	if (lastB==0)
		w = trainbag(bXtrain,bYtrain,B,@traindtw,@dt,treedepth,@splitentropy,minleaf);
	else
		w = trainbagcont(bXtrain,bYtrain,B-lastB,@traindtw,w,treedepth,@splitentropy,minleaf);
	end;
	lastB = B;
	errrate = acc(bXtest,bYtest,@ensemble,w);
	plotx = [plotx;B];
	ploty = [ploty;errrate];
	figure(4);
	plot(plotx,ploty,'k-');
	pause(0.01);
end;
figure(4);
plot(plotx,ploty,'k-');

plx = [];
ply = [];
hold on;
for l = 0:0.5:5
	w2 = retrainensemble(bXtrain,bYtrain,l,w);
	errrate = acc(bXtest,bYtest,@ensemble,w2);
	plx = [plx;(length(w2)-3)/2];
	ply = [ply;errrate];
	figure(4);
	plot(plx,ply,'b-');
	text((length(w2)-3)/2,errrate,sprintf('%g',l));
	pause(0.01);
end;
figure(4);
hold off;
plot(plotx,ploty,'k-');
hold on;
plot(plx,ply,'b-');

bplx = [];
bply = [];
lastB = 0;
for B = 20:20:200
	if (lastB==0)
		[w,al] = trainboost(bXtrain,bYtrain,B,@traindtw,@dt,treedepth,@splitentropy,minleaf);
	else
		[w,al] = trainboostcont(bXtrain,bYtrain,B-lastB,@traindtw,w,al,treedepth,@splitentropy,minleaf);
	end;
	lastB = B;
	errrate = acc(bXtest,bYtest,@ensemble,w);
	bplx = [bplx;B];
	bply = [bply;errrate];
	figure(4);
	plot(bplx,bply,'r-');
	pause(0.01);
end;
figure(4);
hold off;
plot(plotx,ploty,'k-');
hold on;
plot(plx,ply,'b-');
plot(bplx,bply,'r-');
hold off;
legend('Bagging','Bagging, retrained','Boosting');
xlabel('number of trees');
ylabel('testing error rate');

