function errrate = acc(X,Y,testfn,varargin)

Ypred = testfn(X,varargin{:});
errrate = sum(Ypred~=Y)/size(Y,1);

