function [w,alpha] = trainboostcont(X,Y,nrnds,basetrain,w,alpha,varargin)

basetest = w{1};
j = length(w);
for i=1:nrnds,
	modeli = basetrain(X,Y,alpha,varargin{:});
	pred = basetest(X,modeli);
	wr = ~(pred==Y);
	err = sum(alpha(wr));
	if (err>=0.5)
		break;
	end;
	wi = log(1-err) - log(err);
	alphadel = exp(wi);
	alpha(wr) = alpha(wr)*alphadel;
	alpha = alpha / sum(alpha);
	w{j+i*2-1} = modeli;
	w{j+i*2} = wi;
end;
