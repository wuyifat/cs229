function Y = ensemble(X,w)

basetest = w{1};
Y = zeros(size(X,1),1);
for i=2:2:(length(w))
	Y = Y + basetest(X,w{i})*w{i+1};
end;
Y = sign(Y);
