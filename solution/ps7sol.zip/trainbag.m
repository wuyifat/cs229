function w = trainbag(X,Y,nrnds,basetrain,basetest,varargin)

w = {basetest};
for i=1:nrnds,
	modeli = basetrain(X,Y,getbootstrap(size(Y,1)),varargin{:});
	w{i*2} = modeli;
	w{i*2+1} = 1.0/nrnds;
end;

function alpha = getbootstrap(n)

alpha = hist(rand(n,1),((1:n)-0.5)/n)';
