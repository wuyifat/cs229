function w = retrainensemble(X,Y,lambda,w)

Phi = [];
initw = [];
basetest = w{1};
j = 1;
for i=2:2:(length(w))
	Phi(:,j) = basetest(X,w{i});
	initw = [initw w{i+1}];
	j=j+1;
end;

initw = trainlogregL1(Phi,Y,lambda);
j = 1;
newj = 1;
neww = {};
neww{1} = basetest;
for i=2:2:(length(w))
	if (abs(initw(j))>1e-3)
		neww{newj*2} = w{i};
		neww{newj*2+1} = initw(j);
		newj = newj+1;
	end;
	j = j+1;
end;

neww{newj*2} = [1];
neww{newj*2+1} = initw(j);

w = neww;
