function plotdec(testfn,npts,varargin)

axis equal;
v = axis;
[x,y] = meshgrid(v(1):(v(2)-v(1))/npts:v(2),v(3):(v(4)-v(3))/npts:v(4));
[nx,ny] = size(x);
Y = testfn([reshape(x,nx*ny,1) reshape(y,nx*ny,1)],varargin{:});
disp('------------');
disp(sum(Y==-1));
disp(sum(Y==0));
disp(sum(Y==+1));
Y = reshape(Y,nx,ny);
hold on;
[c,h] = contourf(x,y,Y,[-Inf -0.1 0.1 Inf]);
%colormap([0.8 0.6 0.6; 0.8 0.6 0.6; 
%          0.8 0.6 0.6; 0.8 0.6 0.6; 
%          0.6 0.6 0.8; 0.6 0.6 0.8; 0.6 0.6 0.8]);
ch = get(h,'Children');
for i=1:length(ch)
    if (get(ch(i),'CData')<-0.1)
        set(ch(i),'FaceColor',[0.8 0.6 0.6]);
    elseif (get(ch(i),'CData')<0.1)
        set(ch(i),'FaceColor',[0.8 0.6 0.8]);
	else
        set(ch(i),'FaceColor',[0.6 0.6 0.8]);
    end;
end;
