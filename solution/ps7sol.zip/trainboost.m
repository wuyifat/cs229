function [w,alpha] = trainboost(X,Y,nrnds,basetrain,basetest,varargin)

alpha = ones(size(Y))/size(Y,1);

logitboost = 0;

w = {basetest};
for i=1:nrnds,
	if (~logitboost)
		modeli = basetrain(X,Y,alpha,varargin{:});
	else
		modeli = basetrain(X,Y,alpha./(1+alpha),varargin{:});
	end;
	pred = basetest(X,modeli);
	wr = ~(pred==Y);
	err = sum(alpha(wr))/sum(alpha);
	if (err>=0.5)
		break;
	end;
	wi = log(1-err) - log(err);
	alphadel = exp(wi);
	alpha(wr) = alpha(wr)*alphadel;

	if (~logitboost)
		alpha = alpha / sum(alpha);
	else
		alpha(~wr) = alpha(~wr)/alphadel;
	end;

	w{i*2} = modeli;
	w{i*2+1} = wi;
end;
