load -ascii class2d.ascii

trainX = class2d(:,1:2);
trainY = class2d(:,3);

% part a:
w = trainsvm(trainX,trainY,10,@polyk,2,1);
figure(1);
plotsvm(trainX,trainY,50,w,@polyk,2,1);
drawnow;

w = trainsvm(trainX,trainY,10,@gaussk,1);
figure(2);
plotsvm(trainX,trainY,50,w,@gaussk,1);
drawnow;

cs = 10.^(-4:0.5:4);

ks = {@polyk,@polyk,@polyk,@gaussk,@gaussk,@gaussk};
ps = {{1,1},{2,1},{3,1},{5},{1},{0.5}};
names = {'poly 1 1','poly 2 1','poly 3 1','gauss 5','gauss 1','gauss 0.5'};

for i=1:length(ks)
	figure(i+2);
	subplot(1,2,1);
	C = xvalid(trainX,trainY,@trainsvm,@svm,cs,10,5,ks{i},ps{i}{:});
	w = trainsvm(trainX,trainY,C,ks{i},ps{i}{:});
	subplot(1,2,2);
	plotsvm(trainX,trainY,50,w,ks{i},ps{i}{:});
	set(gcf,'NextPlot','add');
	axes;
	h = title(names{i});
	set(gca,'Visible','off');
	set(h,'Visible','on');
	drawnow();
end;
