function K = gaussk(X1,X2,sigma)

n1 = size(X1,1);
n2 = size(X2,1);
D = repmat(X1,[1 1 n2]) - repmat(permute(X2,[3 2 1]),[n1 1 1]);
D = squeeze(sum(D.*D,2));
K = exp(-D/(2*sigma*sigma));

