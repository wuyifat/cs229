function c = xvalid(X,Y,trainf,testf,cs,nfold,nrep,varargin)

n = size(X,1);
eplot = zeros(size(cs));
for k=1:nrep
	p = randperm(n);
	for i=1:length(cs)
		cerr = 0;
		for j=1:nfold,
			testi = p((n*(j-1)/nfold +1) : n*j/nfold);
			traini = p([1:(n*(j-1)/nfold) (n*j/nfold+1):n]);
			w = trainf(X(traini,:),Y(traini,:),cs(i),varargin{:});
			predy = testf(X(testi,:),w,varargin{:});
			predy = sign(predy);
			cerr = cerr + sum(predy~=Y(testi,:)); %/length(testi);
		end;
		eplot(i) = eplot(i)+cerr;
	end;
end;
eplot = eplot / (nrep*nfold);
semilogx(cs,eplot,'k-');
[~,i] = min(eplot);
c = cs(i);
