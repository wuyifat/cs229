function Y = svm(X,w,kernel,varargin)

nsv = w(1);
b = w(2);
alpha = w(3:2+nsv)';
sv = reshape(w(3+nsv:end),[nsv size(X,2)]);

Y = kernel(X,sv,varargin{:})*alpha + b;
