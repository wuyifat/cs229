function w = trainsvm(X,Y,C,kernel,varargin)

[alpha,b] = solvesvm(kernel(X,X,varargin{:}),Y,C);
sv = X(alpha~=0,:);
w = [size(sv,1) b alpha(alpha~=0)' reshape(sv,[1 prod(size(sv))])];
