function K = polyk(X1,X2,d,c),

K = (X1*X2' + c).^d;
