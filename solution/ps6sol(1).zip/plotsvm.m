function plotsvm(X,Y,npts,w,varargin)

h1 = plot(X(Y==1,1),X(Y==1,2),'bx');
hold on;
h2 = plot(X(Y==-1,1),X(Y==-1,2),'ro');
axis equal;

v = axis;
[x,y] = meshgrid(v(1):(v(2)-v(1))/npts:v(2),v(3):(v(4)-v(3))/npts:v(4));
[nx,ny] = size(x);
Z = svm([reshape(x,nx*ny,1) reshape(y,nx*ny,1)],w,varargin{:});
Z = reshape(Z,nx,ny);
map = [ 1.000 0.625 0.625 ;
        0.875 0.625 0.750 ;
        0.750 0.625 0.875 ;
        0.625 0.625 1.000 ;
       ];
caxis([-2 2]);
colormap(map);
contourf(x,y,Z,[min(min(Z)) -1.0 0 1.0 max(max(Z))]);
contour(x,y,Z,[0 0],'LineColor',[0 0 0],'LineWidth',3.0);

% below doesn't work in octave...
uistack([h1; h2],'top');
% use this instead:
% plot(X(Y==1),1),X(Y==1,2),'bx');
% plot(X(Y==-1),1),X(Y==-1,2),'ro');
nsv = w(1);
sv = reshape(w(3+nsv:end),[nsv size(X,2)]);
plot(sv(:,1),sv(:,2),'ko','MarkerSize',10);
hold off;
